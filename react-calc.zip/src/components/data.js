const list = [
    {
        "id": 1,
        "itemName": "Cotton Shirt",
        "itemImg": "cotton",
        "itemDescription": "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        "itemPrice": 250,
        "itemOldPrice": 300,
        "count": 1
    },
    {
        "id": 2, 
        "itemName": "White TShirt",
        "itemImg": "white",
        "itemDescription": "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        "itemPrice": 550,
        "itemOldPrice": 600,
        "count": 1
    },
    {
        "id": 3,
        "itemName": "Full Sleeves Tshirt",
        "itemImg": "full",
        "itemDescription": "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        "itemPrice": 200,
        "itemOldPrice": 250,
        "count": 1
    }
]

export default list;
