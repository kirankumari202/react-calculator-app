
const images = {
    "cotton": require('./cotton-tshirt.png'),
    "full": require('./full-sleeve-tshirt.png'),
    "white": require('./white-tshirt.png')
};

export default images;